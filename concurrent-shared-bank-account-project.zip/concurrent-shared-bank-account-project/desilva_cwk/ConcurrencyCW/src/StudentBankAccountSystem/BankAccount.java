package StudentBankAccountSystem;

//defines interface to bank account
public interface BankAccount {

    int    getBalance( ) ; //returns current balance
    int    getAccountNumber( ) ; //returns Account number
    String getAccountHolder( ) ; //returns Account holder's name

    void deposit( Transaction t ) ; //execute a deposit transaction in bank account
    void withdrawal( Transaction t ) ; //execute a withdrawal transaction in bank account
    boolean isOverdrawn( ) ; //check whether overdrawn or not by returning true id overdrawn , false if not overdrawn
    void printStatement( ) ; //prints out transaction statement
}
