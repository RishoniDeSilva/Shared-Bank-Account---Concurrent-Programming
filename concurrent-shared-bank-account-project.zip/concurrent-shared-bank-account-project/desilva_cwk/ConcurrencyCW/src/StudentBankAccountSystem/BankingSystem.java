package StudentBankAccountSystem;

public class BankingSystem { //Represent complete banking system

    public static void main(String[] args) {

        CurrentBankAccount currentAccount = new CurrentBankAccount(3000,2255, "Rishoni De Silva");
        System.out.println("Create Current Account...");

        ThreadGroup threadObjHuman = new ThreadGroup("ThreadGroup_Human");
        ThreadGroup threadObjCompany = new ThreadGroup("ThreadGroup_Company");
        System.out.println("Create Two Thread Groups...");

        //creates Thread and place it in the ThreadGroup object
        Student student = new Student(threadObjHuman, "Student", currentAccount);
        System.out.println("Thread Student created...");

        //creates Thread and place it in the ThreadGroup object
        StudentLoanCompany loanCompany = new StudentLoanCompany(threadObjCompany, "Student Loan Company", currentAccount, "HSBC");
        System.out.println("Thread loanCompany created...");

        //creates Thread and place it in the ThreadGroup object
        GrandMother grandMother = new GrandMother(threadObjHuman, "GrandMother", "Rosy", currentAccount);
        System.out.println("Thread grandMother created...");

        //creates Thread and place it in the ThreadGroup object
        University university = new University(threadObjCompany, "University", currentAccount, "University of Westminster");
        System.out.println("Thread university created...");

        System.out.println("\n----------------------------------------------------------------------------------------");


        //collect system resources to run thread , schedules it to run and enter in to RUNNABLE state.
        student.start();
        loanCompany.start();
        university.start();
        grandMother.start();

        System.out.println("\nThreads Started to run-----------");

        try {
            student.join();
            loanCompany.join();
            university.join();
            grandMother.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        System.out.println("\nThreads terminated----------");
        currentAccount.printStatement(); //print final statement for the transactions


        System.out.println("\nBank System All Transactions terminated-----------------");
    }
}
