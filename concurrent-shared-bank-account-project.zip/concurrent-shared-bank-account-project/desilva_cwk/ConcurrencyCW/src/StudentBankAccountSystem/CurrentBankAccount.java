package StudentBankAccountSystem;

public class CurrentBankAccount implements BankAccount {

    private int balance; //shows current student account balance
    private int accountNumber;
    private String bankAccountHolder;
    private Statement statement; // add transactions in to statement object

    public CurrentBankAccount(int balance, int accountNumber, String bankAccountHolder) {
        this.balance = balance;
        this.accountNumber = accountNumber;
        this.bankAccountHolder = bankAccountHolder;
        this.statement = new Statement(bankAccountHolder,accountNumber);
    }

    @Override
    public synchronized int getBalance() {
        return balance;
    } //get the final balance

    @Override
    public int getAccountNumber() {
        return accountNumber;
    } //get the student account number

    @Override
    public String getAccountHolder() {
        return bankAccountHolder;
    } //get the account holder name

    //control the access of multiple threads to any shared resource.
    @Override
    public synchronized void deposit(Transaction t) {

        balance = balance + t.getAmount(); //after deposit calculate the balance
        statement.addTransaction(t.getCID(), t.getAmount(), balance); //after calculate new balance update the balance
        notifyAll(); //waken up wait set- threads
    }

    @Override
    public synchronized void withdrawal(Transaction t) {


        if (t.getAmount() > 0) {
            if(this.isOverdrawn()) //check whether the bank account is over drawn or not
            {
                System.out.println(getAccountHolder() + "Your Bank Account : " + getAccountNumber()+ " is overdrawn. Please contact the bank " +
                        " Avaliable Balance : " + getBalance());
            }

            int amount = t.getAmount(); //get the withdraw amount
            while (this.balance < amount) { //verification
                try {

                        System.out.println(getAccountHolder() + " Your Bank Account : " + getAccountNumber()+ " has no sufficient balance to withdraw .Please Wait till funds available" +
                                " Avaliable Balance : " + getBalance());

                    wait(); //Thread is blocked and wait another thread to call notifyAll()
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            balance = balance - t.getAmount(); //calculated the balance
            statement.addTransaction(t.getCID(), t.getAmount(), balance); //update the final balance

        }

    }

    @Override
    public boolean isOverdrawn() {
        //when avaliable balance goes below zero
        if(this.balance < 0){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public void printStatement() {
    statement.print(); //final statement print
    }
}