package StudentBankAccountSystem;

public class GrandMother extends Thread{

    private  String grandMaName;
    BankAccount bankAccount; // Contains information of the student bank account


    public String getGrandMaName() {
        return grandMaName;
    }

    public void setGrandMaName(String grandMaName) {
        this.grandMaName = grandMaName;
    }

    public GrandMother(ThreadGroup threadObjHuman, String name, String grandMaName, BankAccount bankAccount) {
        super(threadObjHuman, name);
        this.grandMaName = grandMaName;
        this.bankAccount = bankAccount;
    }

    @Override
    public void run() {

        //Grandma Top up gifts Transactions started
        System.out.println("\nGrandma "+ getGrandMaName()+" top up gifts Transactions started...");

        //First Grandma top up gifts Transactions - xmaxGift
        System.out.println("\nGrandma " + getGrandMaName()+ " is going to top up gift 2000 ...");
        Transaction xmaxGift = new Transaction(getName(), 2000);
        bankAccount.deposit(xmaxGift); //invoke deposits
        System.out.println("Grandma " + getGrandMaName()+  " top up gifts 2000 Successfully");
        System.out.println(xmaxGift.toString()); //print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //----------------------------------------------------------------------------------------------------


        //Second Grandma top up gifts Transactions - bdayGift
        System.out.println("\nGrandma "+ getGrandMaName()+ " is going to top up gifts 500 ...");
        Transaction bdayGift = new Transaction(getName(), 500);
        bankAccount.deposit(bdayGift);//invoke deposits
        System.out.println("Grandma "+ getGrandMaName()+ " top up gifts  500 Successfully");
        System.out.println(bdayGift.toString()); //print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        System.out.println("\n\nGrandma "+ getGrandMaName()+ " top up gifts Transactions terminates ...");
    }
}
