package StudentBankAccountSystem;

public class University extends Thread{

    BankAccount bankAccount; // Contains information of the student bank account
    private  String university_Name;

    public String getUniversity_Name() {
        return university_Name;
    }

    public void setUniversity_Name(String university_Name) {
        this.university_Name = university_Name;
    }

    public University(ThreadGroup threadObjCompany, String name, BankAccount bankAccount, String university_Name) {
        super(threadObjCompany, name);
        this.bankAccount = bankAccount;
        this.university_Name = university_Name;
    }

    @Override
    public void run() {
        //University Withdrawals has started !!!!

        System.out.println("\n" + getUniversity_Name() + " Withdrawals has started...");

        //First University Withdrawal
        System.out.println("\n" + getUniversity_Name() + " is ready to Withdrawal 500...");
        Transaction firstYearCourseFee = new Transaction(getName(), 500);
        bankAccount.withdrawal(firstYearCourseFee);//invoke withdraw
        System.out.println( getUniversity_Name() + "  Withdrawal  500 Successfully");
        System.out.println(firstYearCourseFee.toString());//print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------------------------------

        //Second University Withdrawal
        System.out.println("\n" + getUniversity_Name() + " is ready to  Withdrawal 3500...");
        Transaction secondYearCourseFee = new Transaction(getName(), 3500);
        bankAccount.withdrawal(secondYearCourseFee);//invoke withdraw
        System.out.println( getUniversity_Name() + " Withdrawal  3500 Successfully");
        System.out.println(secondYearCourseFee.toString());//print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------------------------------


        //Third University Withdrawal
        System.out.println("\n" + getUniversity_Name() + " is ready to Withdrawal 1500...");
        Transaction thirdYearCourseFee = new Transaction(getName(), 1500);
        bankAccount.withdrawal(thirdYearCourseFee);//invoke withdraw
        System.out.println(getUniversity_Name() + " Withdrawal  1500 Successfully");
        System.out.println(thirdYearCourseFee.toString());//print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        //------------------------------------------------------------------------------------------------------------

        System.out.println("\n\n " + getUniversity_Name() + " Transactions has terminated ...");

        //------------------------------------------------------------------------------------------------------------

    }
}
