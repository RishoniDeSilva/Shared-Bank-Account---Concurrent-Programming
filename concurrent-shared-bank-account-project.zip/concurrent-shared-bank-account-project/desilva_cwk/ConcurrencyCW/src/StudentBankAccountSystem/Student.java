package StudentBankAccountSystem;

public class Student extends Thread {

    BankAccount account; //contains information of student


    public Student(ThreadGroup threadObjHuman, String name, BankAccount bankAccount) {
        super(threadObjHuman, name);
        this.account = bankAccount;
    }


    @Override
    public void run() {

        System.out.println("\nStudent Transactions has started...");

        //Student First Transaction
        System.out.println("\nStudent is going to deposit 500...");

        //Win Lottery
        Transaction winLottery = new Transaction(getName(), 500);
        account.deposit(winLottery);//invoke deposits
        System.out.println("Student deposited 500 Successfully");
        System.out.println(winLottery.toString()); //print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------

        //Student Second Transaction
        System.out.println("\nStudent  is going to  withdraw 2000...");

        Transaction buyGoods = new Transaction(getName(), 2000);
        account.withdrawal(buyGoods);//invoke withdraw
        System.out.println("Student withdrawed 2000 Successfully");
        System.out.println(buyGoods.toString()); //print single transaction

        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------

        //Student Third Transaction
        System.out.println("\nStudent  is going to  deposit 1000...");

        Transaction xmasGift = new Transaction(getName(), 1000);
        account.deposit(xmasGift);//invoke deposits
        System.out.println("Student deposited 1000 Successfully");
        System.out.println(xmasGift.toString()); //print single transaction

        //sleeping for a random about time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------

        //Student Forth Transaction
        System.out.println("\nStudent  is going to  deposit 500...");

        Transaction internSalary = new Transaction(getName(), 500);
        account.deposit(internSalary);//invoke deposits
        System.out.println("Student deposited 500 Successfully");
        System.out.println(internSalary.toString()); ////print single transaction

        //sleeping for a random about time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------


        //Student Fifth Transaction
        System.out.println("\nStudent  is going to  withdraw 600...");

        Transaction buyFood = new Transaction(getName(), 600);
        account.withdrawal(buyFood);//invoke withdraw
        System.out.println("Student withdrawed 600 Successfully");
        System.out.println(buyFood.toString()); ////print single transaction

        //sleeping for a random about time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------


        //Student Sixth Transaction
        System.out.println("\nStudent  is going to  withdraw 500...");

        Transaction givePresentToMother = new Transaction(getName(), 600);
        account.withdrawal(givePresentToMother);//invoke withdraw
        System.out.println("Student withdrawed 500 Successfully");
        System.out.println(givePresentToMother.toString());

        //sleeping for a random about time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------

        System.out.println("\n\nStudent  Transactions terminates ...");

        //------------------------------------------------------------------------------------

    }

}