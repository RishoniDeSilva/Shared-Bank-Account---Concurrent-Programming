package StudentBankAccountSystem;

public class StudentLoanCompany extends Thread{

    BankAccount account; //contains information of student account
    private String loanCompanyName;

    public String getLoanCompanyName() {
        return loanCompanyName;
    }

    public void setLoanCompanyName(String loanCompanyName) {
        this.loanCompanyName = loanCompanyName;
    }

    public StudentLoanCompany(ThreadGroup threadObjCompany, String name, BankAccount account, String loanCompanyName) {
        super(threadObjCompany, name);
        this.account = account;
        this.loanCompanyName = loanCompanyName;
    }

    @Override
    public void run() {
      System.out.println("\nStudent Loan Company " + getLoanCompanyName() +" Transactions started...");


        //First Loan Company Transaction
        System.out.println("\nStudent Loan Company "+ getLoanCompanyName() +" is ready to deposits 1000...");
        Transaction firstYearCourseFee = new Transaction(getName(),1000);
        account.deposit(firstYearCourseFee);//invoke deposits
        System.out.println("Student Loan Company "+ getLoanCompanyName() +" deposited 1000 Successfully");
        System.out.println(firstYearCourseFee.toString()); //print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //------------------------------------------------------------------------------------------------------------------------

        //Second Loan Company Transaction
        System.out.println("\nStudent Loan Company "+ getLoanCompanyName() +" is ready to deposits 100...");
        Transaction secondYearCourseFee = new Transaction(getName(),100);
        account.deposit(secondYearCourseFee);//invoke deposits
        System.out.println("Student Loan Company "+ getLoanCompanyName() + " deposited 100 Successfully");
        System.out.println(secondYearCourseFee.toString()); //print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        //------------------------------------------------------------------------------------------------------------------------


        //Third Loan Comapany Transaction
        System.out.println("\nStudent Loan Company "+ getLoanCompanyName() + " is ready to deposits 200...");
        Transaction thirdYearCourseFee = new Transaction(getName(),200);
        account.deposit(thirdYearCourseFee);//invoke deposits
        System.out.println("Student Loan Company "+ getLoanCompanyName() +" deposited 200 Successfully");
        System.out.println(thirdYearCourseFee.toString());//print single transaction

        //sleeping for a random amount of time
        try {
            Thread.sleep((long) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        System.out.println("\n\nStudent  Loan Company "+ getLoanCompanyName() +" Transactions has terminated ...");


    }
}
